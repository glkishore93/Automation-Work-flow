package excelExportAndFileIO;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
public class PopupHandler {
	public void popup() throws Exception {
		WebDriver driver = new InternetExplorerDriver();
		String parentWindowHandler = driver.getWindowHandle(); // Store your parent window

		String subWindowHandler = null;
		
		Set<String> handles = driver.getWindowHandles();
		
		Iterator<String> iterator = handles.iterator();
		
		String message="";	
	
		while (iterator.hasNext()){
			    subWindowHandler = iterator.next();			   
		
			    driver.switchTo().window(subWindowHandler); // switch to popup window
			    
			    driver.findElement(By.cssSelector("div.alertcontent")).click();
			    
			    message = driver.findElement(By.cssSelector("div.alertcontent")).getText();
			    Thread.sleep(3000);
			    }
			    
	    driver.findElement(By.id("btnOK")).click();
	    Thread.sleep(3000);
	    driver.switchTo().window(parentWindowHandler); 
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
