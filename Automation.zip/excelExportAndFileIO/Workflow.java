package excelExportAndFileIO;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class Workflow {
static WebDriver driver;
public static FileInputStream fis;
public static XSSFWorkbook workbook;
static XSSFSheet sheet;
static XSSFRow row;
static  String fieldids [];
//static String stepids [] =r.getstepid();
//static String userids []=r.getuserid();;

static final String JDBC_DRIVER = "com.sqlserver.jdbc.Driver";  
static final String DB_URL = "jdbc:sqlserver://192.168.0.1\\sql_14";
static final String USER = "kishore";
static final String PASS = "Temp@123";
static String Ref;
static String ids;
static String [] stepids;
static String [] userid;
static String loopstepids[];
static HashMap<String, String> map = new HashMap<>();
static HashMap<String, String> step_and_use_id_map = new HashMap<>();
static HashMap<String, String> user_id_and_username_map = new HashMap<>();
static HashMap<String, String> username_and_passwd_map = new HashMap<>();
static HashMap<String,String> username_and_transpasswd_map=new HashMap<>();
static HashMap<String, String> step_id_action_map = new HashMap<>();

	public Workflow(WebDriver driver,String Ref) throws Exception {
		user_credentials u = new user_credentials();
		
		username_and_passwd_map=u.username_password_map;
		System.out.println("the password for  :    "+username_and_passwd_map.get("pdhead") );
		username_and_transpasswd_map=u.username_trans_password_map;
		user_id_and_username_map=u.username_useid_map;
		Workflow.driver=driver;
		String a []=Ref.split(",");
		Workflow.Ref=a[5];
		ids=	stepiduserid();
		
		String initiation_page_step_ids [] = {"1","7","6","10","18","25","32"};
		for(int i=0;i<initiation_page_step_ids.length;i++) {
			
			step_id_action_map.put(initiation_page_step_ids[i],"initiation");
		}
		String annotation_page_step_ids [] = {"2","3","14","21","67","72"};
		for(int j=0;j<annotation_page_step_ids.length;j++) {
			
			step_id_action_map.put(annotation_page_step_ids[j],"annotation");
		}
		step_id_action_map.put("8", "document");
		step_id_action_map.put("9", "workflow_authorise");
		String ar[] = getstepid_in_0_nd_userid_in_1();
		String temp = ar[0];
		
		//
	 stepids =temp.substring(1, temp.length()).split(",");
	 String steptem[]=stepids;
	String temper =printDistinctElements(steptem);
	 loopstepids =temper.split(",");
	 // Substring(1, temp.length());
			 
				
	 	String temp1=ar[1];
		userid=temp1.substring(1, temp1.length()).split(",");

		System.out.println(Arrays.toString(stepids));
		
		for(int i=0;i<stepids.length;i++) {
			
				step_and_use_id_map.put(stepids[i], userid[i]);
				
				System.out.println(Arrays.toString(userid));
			
			System.out.println(step_and_use_id_map.get(stepids[i]));
		}
		Iterator<?> iter =step_and_use_id_map.entrySet().iterator();
		 while (iter.hasNext()) {
		     @SuppressWarnings("rawtypes")
			Map.Entry mEntry = (Map.Entry) iter.next();
	   System.out.println(mEntry.getKey() + "  ::  " + mEntry.getValue());
		 }
		 Iterator<?> iter1 =user_id_and_username_map.entrySet().iterator();
		 while (iter1.hasNext()) {
		     @SuppressWarnings("rawtypes")
			Map.Entry mEntry = (Map.Entry) iter1.next();
	   System.out.println(mEntry.getKey() + "  ::  " + mEntry.getValue());
		 }
		 Iterator<?> iter2 = username_and_passwd_map.entrySet().iterator();
		 while (iter2.hasNext()) {
		     @SuppressWarnings("rawtypes")
			Map.Entry mEntry = (Map.Entry) iter2.next();
	   System.out.println(mEntry.getKey() + "  ::  " + mEntry.getValue());
		 }
		 workflow_action();
		// TODO Auto-generated constructor stub
	}
	 public String  printDistinctElements(String arr[]){
         String temp="";
	        for(int i=0;i<arr.length;i++){
	            boolean isDistinct = false;
	            for(int j=0;j<i;j++){
	                if(arr[i].equals(arr[j]) ){
	                    isDistinct = true;
	                    break;
	                }
	            }
	            if(!isDistinct){
	            	temp=temp+","+arr[i];
	                System.out.print(arr[i]+" ");
	            }
	        }
	        String temp1 =temp.substring(1,temp.length());
	        return temp1;
	    }
	public String getformid() {
		Connection conn = null;
		Statement stmt = null;

		 String formid="";
		 String ref_num="";
			try{

				  DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
				  //STEP 3: Open a connection
			      System.out.println("Connecting to database...");
			      conn = DriverManager.getConnection(DB_URL,USER,PASS);
			      //STEP 4: Execute a query
			      System.out.println("Creating statement...");
			      stmt = conn.createStatement();
			      String sql1 = "select FORM_NF_ID from [Greatfour_Platform_HarmonyV4.0].[dbo].[FORMS] where FORM_CF_REFERENCE_NUMBER =";
			      //  Scanner sc = new Scanner(System.in);			    
			      //  String array [];
			      System.out.println("Please Enter the reference Number......     "+  Ref);
			     ref_num=Ref;
			    //sc.nextLine();
			    // ref=ref_num;
			      sql1=sql1+ref_num;
			      System.out.println(sql1);
			      ResultSet rs=stmt.executeQuery(sql1);
       //     String flowid="";
			    while(rs.next()) {
			     
			      formid=rs.getString("FORM_NF_ID");
				    System.out.println("FORM ID :  "+formid);
			    }
			 //   System.out.println("FORM ID :  "+formid);
			      rs.close();				     
			      stmt.close();
			      conn.close();
			      System.out.println(formid);
			return formid;
			 
		   }catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		            stmt.close();
		      }catch(SQLException se2){
		      }// nothing we can do
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try
		   System.out.println("Goodbye!"+formid);
			return null;
		}
	public String stepiduserid() {
		Connection conn = null;
		Statement stmt = null;
		String formid = getformid();
	//	WriteExcel w = new WriteExcel();
	System.out.println("FORM ID :  "+formid);
			try{

				  DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
				   //STEP 3: Open a connection
			      System.out.println("Connecting to database...");
			      conn = DriverManager.getConnection(DB_URL,USER,PASS);
			  

			      //STEP 4: Execute a query [FORMS]
			      System.out.println("Creating statement...");
			      stmt = conn.createStatement();
			      String sql1 = "select UA_NF_STEP_ID,UA_NF_USR_ID from [Greatfour_Platform_HarmonyV4.0].[dbo].[USER_AUTHORIZATION] where UA_NF_FORM_ID =";

			  
			      sql1=sql1+formid;
			      System.out.println(sql1);
			      ResultSet rs=stmt.executeQuery(sql1);
			     //     String flowid="";
			      String stepid="";
			      String userid="";
			     
			      while(rs.next()) {
			     
			      stepid=stepid+","+rs.getString("UA_NF_STEP_ID");
			      userid=userid+","+rs.getString("UA_NF_USR_ID");
			     // System.out.println(stepid+"hiiii"+userid);
			    }
			  
			      rs.close();				     
			      stmt.close();
			      conn.close();
			      System.out.println(formid);
			return stepid+",,"+userid;
			 
		   }catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		            stmt.close();
		      }catch(SQLException se2){
		      }// nothing we can do
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try
		   System.out.println("Goodbye!");
			return null;
	
	}
	public String [] getstepid_in_0_nd_userid_in_1() {
		System.out.println(ids);
		String ar []=ids.split(",,");
		
		
		return ar;
		
	}

	public void getRowNum() {
		Connection conn = null;
		Statement stmt = null;

		 String formid="";
		 String ref_num="";
			try{

				  DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
				   //STEP 3: Open a connection
			      System.out.println("Connecting to database...");
			      conn = DriverManager.getConnection(DB_URL,USER,PASS);
			  

			      //STEP 4: Execute a query
			      System.out.println("Creating statement...");
			      stmt = conn.createStatement();
			      String sql ="select Top 1 FORM_CF_REFERENCE_NUMBER  from [Greatfour_Platform_HarmonyV4.0].[dbo].[FORMS]";
			      ResultSet rs_sql = stmt.executeQuery(sql);
//			      ResultSet rs1 = stmt.executeQuery("Select count(*) from [Greatfour_Platform_HarmonyV4.0].[dbo].[FORMS] where  form_nf_status =1 and Form_nf_is_migrated=0 ");
//			      while(rs1.next()) {
//			    	  count =Integer.parseUnsignedInt(rs1.getString("count") );
//			      }
			      String last_ref_num="";
			      while(rs_sql.next()) {
			    	  last_ref_num= rs_sql.getString("FORM_CF_REFERENCE_NUMBER");
			    	 
			      }
			      rs_sql.close();
			      String sql1 = "select  Row_Number() Over (order by FORM_CF_REFERENCE_NUMBER desc ) as RowNum, FORM_CF_REFERENCE_NUMBER from [Greatfour_Platform_HarmonyV4.0].[dbo].[FORMS] where FORM_CF_REFERENCE_NUMBER>="+"'"+last_ref_num+"'";
			
			      
//Scanner sc = new Scanner(System.in);
		//	     String array [];
		//	      System.out.println("Please Enter the reference Number......");
//			     ref_num=sc.nextLine();
//			      sql1=sql1+ref_num;
			      String ref_n="";
			      String row_num="";
			      System.out.println(sql1);
			      ResultSet rs=stmt.executeQuery(sql1);
			     //     String flowid="";
			    while(rs.next()) {
			     
			      ref_n=rs.getString("FORM_CF_REFERENCE_NUMBER");
			      row_num=rs.getString("RowNum");
			      map.put(ref_n, row_num);
			  System.out.println(map.get(ref_n)+"value"+ ref_n);   
			    
			    }
			   System.out.println("The row outside it :"+ map.get(Ref));
			      rs.close();				     
			      stmt.close();
			      conn.close();
			     // System.out.println(formid);
			
			 
		   }catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		            stmt.close();
		      }catch(SQLException se2){
		      }// nothing we can do
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try
		   System.out.println("Goodbye!");
	}
	///Initiation/////////////////////////////
	public String []  databaseIds() {
		Connection conn = null;
		Statement stmt = null;
		String fields="";
		 try{
		      //STEP 2: Register JDBC driver C:\\Users\\G411\\Downloads\\excel\\sampleinitiate.xlsx
			   DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
			   //STEP 3: Open a connection
		      System.out.println("Connecting to database...");
		      conn = DriverManager.getConnection(DB_URL,USER,PASS);
		  

		      //STEP 4: Execute a query
		      System.out.println("Creating statement...");
		      stmt = conn.createStatement();
		      String sql;
		      sql="select WFDEF_CF_ENABLED_FIELDS from  [Greatfour_Platform_HarmonyV4.0].[dbo].[WORKFLOW_DEFINITION] where WFDEF_WFM_NF_ID=2009 and WFDEF_NF_SEQUENCE=1";
		      ResultSet rs  = stmt.executeQuery(sql);
		      while(rs.next()) {
		     
		      fields = rs.getString("WFDEF_CF_ENABLED_FIELDS");
		     }
		      rs.close();
			     
		      stmt.close();
		      conn.close();
		
		 
	   }catch(SQLException se){
	      //Handle errors for JDBC
	      se.printStackTrace();
	   }catch(Exception e){
	      //Handle errors for Class.forName
	      e.printStackTrace();
	   }finally{
	      //finally block used to close resources
	      try{
	         if(stmt!=null)
	            stmt.close();
	      }catch(SQLException se2){
	      }// nothing we can do
	      try{
	         if(conn!=null)
	            conn.close();
	      }catch(SQLException se){
	         se.printStackTrace();
	      }//end finally try
	   }//end try
	   System.out.println("Goodbye!");
	   

	   return fields.split(",");
	}
	
	public void createExcelsheet() {
		String fields [] = databaseIds();
		Connection conn = null;
		Statement stmt = null;
		WriteExcel w = new WriteExcel();
		for(int i =0;i<fields.length;i++) {
			 try{

				   DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
				   //STEP 3: Open a connection
			      System.out.println("Connecting to database...");
			      conn = DriverManager.getConnection(DB_URL,USER,PASS);
			  
			    
			      //STEP 4: Execute a query
			      System.out.println("Creating statement...");
			      stmt = conn.createStatement();
			      String sql="select FLD_CF_DATATYPE,FLD_CF_NAME from   [Greatfour_Platform_HarmonyV4.0].[dbo].[fields] where FLD_TEMPLATEID=7 ";
			      
			    
			      
			      ResultSet rs  = stmt.executeQuery(sql);
			      while(rs.next()) {
			     
			      String datatype = rs.getString("FLD_CF_DATATYPE");
			      String name =rs.getString("FLD_CF_NAME");
			      String fispath="C:\\Users\\G411\\Desktop\\control\\Dashboard.xlsx";
			      w.writeExcell(i+1, fields[i],fispath, name, datatype);
			      
			     }
			      rs.close();
				     
			      stmt.close();
			      conn.close();
			
			 
		   }catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		            stmt.close();
		      }catch(SQLException se2){
		      }// nothing we can do
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try
		   System.out.println("Goodbye!");
			
		}
	}
	public void fillRemainingfields() throws IOException, InterruptedException {
		fis = new FileInputStream("C:\\\\\\\\Users\\\\\\\\G411\\\\\\\\Desktop\\\\\\\\Initiation\\\\\\\\sampleinitiate.xlsx");
		 workbook= new XSSFWorkbook(fis); 
		XSSFSheet sheet= workbook.getSheetAt(0);
	//	System.out.println(Arrays.toString(fieldids));
		 int rc = sheet.getLastRowNum();
		for(int i=1;i<rc;i++) {
			System.out.println("inside the loop");
			 row =sheet.getRow(i);
			 String id = row.getCell(0).getStringCellValue();
			 String datatype =row.getCell(1).getStringCellValue();
			 System.out.println(datatype);
			 
			 if(datatype.equals("4")) {
				 try {
					 	System.out.println("In try");
						WebElement w = driver.findElement(By.id(id));
							if(w.isEnabled()) {	
							System.out.println("Element is enabled");
							Select listbox = new Select(w);
							
							//System.out.println("JSDYAZ");
							w.click();			
							listbox.selectByVisibleText(row.getCell(3).getStringCellValue());
							System.out.println("Element  is found and Selected : "+ "\n");
							
							}
						
					}
				 catch(Exception e) {
					 System.out.println(e);
					 continue;
				}
				  
				 
			 }
			 else if(datatype.equals("2")) {
				 try {
					 WebElement w = driver.findElement(By.id(id));
						if(w.isEnabled()) {	
							w.sendKeys(row.getCell(3).getStringCellValue());
							
						}
				 }
				 catch(Exception e) {
					 System.out.println(e);
					 continue;
				 }
			 }
			 
		}
		Thread.sleep(2000);
		 driver.findElement(By.id("btn6")).click();
		 driver.findElement(By.id("btnFirst")).click();
	}
	/////////////////////////////////////
	public void login(String s,String s1) throws InterruptedException {
		driver.manage().window().maximize();
		Thread.sleep(1600);
		driver.findElement(By.id("txtLoginName")).sendKeys(s);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Thread.sleep(1300);
		driver.findElement(By.id("txtPassword")).sendKeys(s1);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.id("btnLogin")).click();		
	}
	public void logout() throws InterruptedException {
		Thread.sleep(4000);
		WebElement we = driver.findElement(By.cssSelector("label.lblmpdrpdwnshrtname.whitecolorfont"));
		we.click();		
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("button.hrmnybtn")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("div.alertbuttons > #btnFirst")).click();

}
	public void platform() {
		WebElement w = driver.findElement(By.id("dbNames"));
		w.click();
		Select listbox = new Select(w);
		listbox.selectByVisibleText("Harmony");
	}
	public void workflow_action() throws InterruptedException, Exception {
//		String initiation_page_step_ids [] = {"1","7","6","10","18","25","32"};
//		String annotations_page_step_ids [] = {"2","3","14","21","67","72"};
		Thread.sleep(2000);
		System.out.println("First ::         dkopkepdw[pkqdpoe3=-"+"\n");
		for(int i=0;i<loopstepids.length;i++) {
			System.out.println("Second ::         dkopkepdw[pkqdpoe3=-");
			driver.findElement(By.cssSelector("img.imgharmonyapps")).click();
			System.out.println("Third ::         dkopkepdw[pkqdpoe3=-");
			driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
			System.out.println("Fourth ::         dkopkepdw[pkqdpoe3=-");
			driver.findElement(By.id("div'7'")).click();
			Thread.sleep(3000);
			System.out.println("fifth ::         dkopkepdw[pkqdpoe3=-");
			String temp =step_and_use_id_map.get(loopstepids[i]);
			System.out.println("sixth ::         dkopkepdw[pkqdpoe3=-");
		System.out.println(temp+"//////////////////////////////////////////AOSJPOa   "+loopstepids[i]);
			System.out.println("sevenh ::         dkopkepdw[pkqdpoe3=-");
			String u = user_id_and_username_map.get(temp);
			String p = username_and_passwd_map.get(u);
			System.out.println("username is :  " +u);
			System.out.println("password is :  " +p);
			/////////
			////logout
			logout();
//			Login
			platform();
			login(u,p);
			String temp1 =step_id_action_map.get(loopstepids[i]);
			System.out.println(temp1+"qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq");
			if(step_id_action_map.get(loopstepids[i]).equals("initiation")) {
				authorise();	
			Initiate(p);
			System.out.println("\n "+"This to check what is happenoing after calling the initiate method"+"\n");
			
				
			}
			
			else if(step_id_action_map.get(loopstepids[i]).equals("document")) {
				upload_document();
				
			}
//		if(stepids[i].equals("8")){
//			/// document upload
//			upload_document();
//				
//		}
//		else if(stepids[i].equals("9")) {
//				/// workfloe Authorise
//			authorise();
//		}
//		for(int j =0;j<initiation_page_step_ids.length;j++) {
//			if(stepids[i].equals(initiation_page_step_ids[j])) {
//				Initiate(); 
//					
			
//			}
//			break;
//		}	
			System.out.println("The iteration is      "+i+"//////"+stepids[i]);
			
		}
	}
	public void btn_ids_doc() throws InterruptedException {
	int i=0;
		
		
		driver.findElement(By.id("lblfile1")).sendKeys("sample.pdf");;
		Thread.sleep(4000);
		driver.findElement(By.id("lblfile6")).sendKeys("sample.pdf");
		Thread.sleep(4000);
		driver.findElement(By.id("lblfile8")).sendKeys("img.jpg");
		Thread.sleep(4000);
		driver.findElement(By.id("lblfile63")).sendKeys("img.jpg");
		Thread.sleep(4000);
		driver.findElement(By.id("lblfile64")).sendKeys("img.jpg");
		Thread.sleep(4000);
		driver.findElement(By.id("lblfile66")).sendKeys("img.jpg");
		Thread.sleep(4000);
		driver.findElement(By.id("lblfile67")).sendKeys("img.jpg");
		Thread.sleep(4000);
		
		
		driver.findElement(By.id("btnUploadAll")).click();
		driver.findElement(By.id("btnOK")).click();	
	}
	public void upload_document() throws InterruptedException {
		
		String s1="(//img[contains(@src,'http://192.168.0.1/HarmonyV4.0/Images/Documents.png')])[";
		String rn=map.get(Ref)+"]";
		System.out.println("document xpath is :      "+s1+rn);
		//driver.findElement(By.xpath(s1+rn)).click();
		driver.findElement(By.cssSelector("img.imgdotswidth")).click();
		driver.findElement(By.cssSelector("a[title=\"Documents\"] > img.gridActionButton")).click();
		btn_ids_doc();
	}
	public void authorise() throws InterruptedException {

		System.out.println("authoriseeeeeeeeeeee");
		String s = "(//div[@id='dvAllCheckListPercentage']/span)";
		String s1 ="["+map.get(Ref)+"]";
		System.out.println("authorise xpath is  :  " +s+s1);
		driver.findElement(By.cssSelector("#dvAllCheckListPercentage > span")).click();
		//driver.findElement(By.xpath(s+s1)).click();//
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.id("AuthurAll")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.id("btnFirst")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.id("btnFirst")).click();
	}
	public void Initiate(String p) throws IOException, InterruptedException {
//		driver.findElement(By.id("btnShowfilter")).click();
//		WebElement w  = driver.findElement(By.id("calender"));
//		w.click();
//		Select listbox = new Select(w);
//		listbox.selectByVisibleText("Yearly");
//		driver.findElement(By.id("btnHideFilters")).click();
//		System.out.println("The Text is :  "+driver.findElement(By.id("lblmaxRange")).getText());	
//		boolean flag = false;
////		for(int k=0;k<500;k++) {
////			try {
////				System.out.println("/////////////////DashBoard//////////////////////");
//				for(int l =0;l<50;l++) {	
//					
//					try {
//						Thread.sleep(2000);
//						System.out.println(Ref);
//						String x="//a[contains(text(),";
//						x =x+ Ref + ")]";//a[contains(text(),'2018\586-1')]/////a[contains(text(),''2018\588-1'')]
//						System.out.println("the Xpath is :    "+x);
//						driver.findElement(By.xpath(x)).click();
//						fillRemainingfields();
//						flag=true;
//						return flag;
//					}
//					catch(Exception e) {
//						continue;
//					}
//			
//				}
		
			driver.findElement(By.cssSelector("a.gridActionButton")).click();
//			WebElement w = driver.findElement(By.id(id));
			WebElement w = driver.findElement(By.id("1031"));
			if(w.isEnabled()) {	
				w.sendKeys("shfihfd");
				
			}
			 driver.findElement(By.id("btn6")).click();
			try {
				driver.findElement(By.id("txtCommnets")).sendKeys("Automation sample");
				
				
			}
				catch(Exception e) {
					System.out.println(e);
				}
			 driver.findElement(By.id("btnFirst")).click();
			try {
				driver.findElement(By.id("btnOK")).click();		

			}
			catch(Exception e ) {
				System.out.println(e);
			}
			try {
				driver.findElement(By.id("txtPassword")).sendKeys(p);
				Thread.sleep(2000);
				driver.findElement(By.id("btnLogin")).click();	
			}
			catch(Exception e) {
				
			}
			try {
				driver.findElement(By.id("btnOK")).click();		

			}
			catch(Exception e ) {
				System.out.println(e);
			}
			Thread.sleep(30000);
		//	btn_ids_doc();
			
			
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	Workflow w = new Workflow(driver,"2018\\586-2");
		//w.getRowNum();
	}

}
