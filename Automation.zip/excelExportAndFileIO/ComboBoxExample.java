package excelExportAndFileIO;

import javax.swing.*;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;

import java.awt.event.*;
import java.io.FileInputStream;
import java.lang.reflect.Constructor;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;    
public class ComboBoxExample {    
JFrame f;    
ComboBoxExample(){    
    f=new JFrame("ComboBox Example");   
    final JLabel label = new JLabel();          
    label.setHorizontalAlignment(JLabel.CENTER);  
    label.setSize(400,100);  
    JButton b=new JButton("Show");  
    b.setBounds(200,100,75,20);  
    String languages[]={"C","C++","C#","Java","PHP"};        
    final JComboBox cb=new JComboBox(languages);    
    cb.setBounds(50, 100,90,20);    
    f.add(cb); f.add(label); f.add(b);    
    f.setLayout(null);    
    f.setSize(350,350);    
    f.setVisible(true);       
    b.addActionListener(new ActionListener() {  
        public void actionPerformed(ActionEvent e) {       
String data = "Programming language Selected: "   
   + cb.getItemAt(cb.getSelectedIndex());  
label.setText(data);  
}  
});           
}    
}
//Controller c = new Controller();				
//FileInputStream fis = new FileInputStream("C:\\Users\\G411\\Desktop\\control\\Controller_class.xlsx");
//workbook = new XSSFWorkbook(fis);		
//XSSFSheet sheet = workbook.getSheetAt(0);
//int rc = sheet.getLastRowNum();
//System.out.println(rc);
//
//JFrame f=new JFrame("Harmony_v4.0");  
//
//Map<String,String> mMap  = new HashMap<String, String>();
//Map<String,String> mMap1  = new HashMap<String, String>();
//String[] Classes = new String [rc+1];
//String[] Values = new String [rc+1];
//String Test_Case []=new String[rc+1];
//
//for(int j=0;j<=rc;j++) {
//	Row row1 = sheet.getRow(j);
//	String Test_case=row1.getCell(0).getStringCellValue();
//	String className = row1.getCell(1).getStringCellValue();
//	String values = row1.getCell(2).getStringCellValue();
//	Test_Case[j]=Test_case; 
//	Values[j]=className+",,"+values;
//	 System.out.println(Arrays.toString(Test_Case));
//	 mMap.put(Test_Case[j],Values[j]);
//	 Iterator iter = mMap.entrySet().iterator();
//	 while (iter.hasNext()) {
//	     Map.Entry mEntry = (Map.Entry) iter.next();
//   System.out.println(mEntry.getKey() + " : " + mEntry.getValue());
//	 }
//}
// f=new JFrame("ComboBox Example");   
//  
//    final JComboBox cb=new JComboBox(Test_Case);    
//    cb.setBounds(50, 200,290,20);    
//    f.add(cb); 
//    f.setLayout(null);    
//    f.setSize(400,400);    
//    f.setVisible(true);       
//    cb.addActionListener(new ActionListener() {  
//    public void actionPerformed(ActionEvent e) {       
//    	for(int m=0;m<Test_Case.length;m++) {	
//        	String data = ""+ cb.getItemAt(cb.getSelectedIndex());  
//			System.out.println(mMap.get(data));
//			String cl= mMap.get(data);
//			String cln[]=cl.split(",,");
//			String clsnm[]=cln[0].split(",");
//			String val="";
//			
//				for(int k=0;k<clsnm.length;k++) {
//				System.out.println("clasnm"+"\t"+clsnm[k]);
//				try {
//				
//					Class<?> clsname = Class.forName(clsnm[k]);
//					String []value =cln[1].split(",,,");
//					for(int i=0;i<value.length;i++) {	
//						String []number_of_values=value[i].split(",");
//						System.out.println("length:  "+number_of_values.length);
//						for(int l=0;l<number_of_values.length;l++) {
//					
//							String []named_Value_pairs=number_of_values[l].split("::");
//							String Key=named_Value_pairs[0];
//							String key_value=named_Value_pairs[1];
//							mMap1.put(Key, key_value);
//							System.out.println(Arrays.toString(named_Value_pairs));
//							}
//							Iterator iter = mMap1.entrySet().iterator();
//							while(iter.hasNext()) {
//								if(!mMap1.containsKey("filepath")) {
//									val	=mMap1.get("username");
//									val+=","+mMap1.get("password")+","+mMap1.get("url");
//							System.out.println(val);
//								}
//								else
//									val=mMap1.get("username")+","+mMap1.get("password")+","+mMap1.get("url")+mMap1.get("filepath");
//							String val1 [] = val.split(",");
//							System.out.println(Arrays.toString(val1));
//							break;
//							}
//								if(clsname.equals("excelExportAndFileIO.Logout")) {
//									Constructor<?> ctor1 = clsname.getConstructor(WebDriver.class);
//									Object object1 = ctor1.newInstance(new Object[] {driver});
//												
//								}
//								else {
//									System.out.println("     hello");
//									Constructor<?> ctor1 = clsname.getConstructor(WebDriver.class,String.class);
//									System.out.println(driver);
//									Object object1 = ctor1.newInstance(new Object[] {driver,val});
//									System.out.println("hello111");
//									}
//								
//							
//						}
//						}
//						catch(Exception e1) {
//							System.out.println(e1);
//				
//						}
//					}	
//    	}			
//			
//    }
//});       
//
//
//
//public static void main(String[] args) {    
//    new ComboBoxExample();         
//}    
//}    