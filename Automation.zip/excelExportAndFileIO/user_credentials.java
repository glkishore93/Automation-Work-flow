package excelExportAndFileIO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

import com.gargoylesoftware.htmlunit.javascript.host.Map;

public class user_credentials {
	static final String JDBC_DRIVER = "com.sqlserver.jdbc.Driver";  
	static final String DB_URL = "jdbc:sqlserver://192.168.0.1\\sql_14";
	static final String USER = "kishore";
	static final String PASS = "Temp@123";
	WriteExcel w = new WriteExcel();
	static HashMap<String, String> username_trans_password_map;
	static HashMap<String, String> username_password_map;
	static HashMap<String, String>username_useid_map;
	public user_credentials() {
		username_trans_password_map = new HashMap<>();
		username_password_map = new HashMap<>();
		username_useid_map=new HashMap<>();
		// TODO Auto-generated constructor stub
		get_credentials();
	}
	 public String convertHexToString(String hex){

		  StringBuilder sb = new StringBuilder();
		  StringBuilder temp = new StringBuilder();
		  
		  //49204c6f7665204a617661 split into two characters 49, 20, 4c...
		  for( int i=0; i<hex.length()-1; i+=2 ){
			  
		      //grab the hex in pairs
		      String output = hex.substring(i, (i + 2));
		      //convert hex to decimal
		      int decimal = Integer.parseInt(output, 16);
		      //convert the decimal to character
		      sb.append((char)decimal);
			  
		      temp.append(decimal);
		  }
		//  System.out.println("Decimal : " + temp.toString());
		  
		  return sb.toString();
	  }
	public void get_credentials() {
		
		
		Connection conn = null;
		Statement stmt = null;
		
		 String formid="";
		 String ref_num="";
			try{

				  DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
				   			//STEP 3: Open a connection
			      System.out.println("Connecting to database...");
			      conn = DriverManager.getConnection(DB_URL,USER,PASS);
			  			     //STEP 4: Execute a query
			      System.out.println("Creating statement...");
			      stmt = conn.createStatement();
			      String sql ="select usr_password,usr_trans_password,usr_name,USR_ID from [Greatfour_Platform_HarmonyV4.0].[users].[users]";
			      ResultSet rs =stmt.executeQuery(sql);
			      String password="";
			      String username="";
			      String trans_password="";
			      String usr_id="";
			      int i=1;
			      while(rs.next()) {
			    	String pass= rs.getString("usr_password");
			    	 username= rs.getString("usr_name");
			    	 usr_id=rs.getString("usr_id");
			    	 String trans_pass=rs.getString("usr_trans_password");
			    	 password=convertHexToString(pass);
			    	 trans_password=convertHexToString(trans_pass);
			    	 username_password_map.put(username, password);
			    	 username_trans_password_map.put(username,trans_password);		
			    	 username_useid_map.put(usr_id,username);
			      }
			      rs.close();
			      stmt.close();	
			      conn.close();
		
		   }catch(SQLException se){
			   			//Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
			   			//Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
			   			//finally block used to close resources
		      try{
		         if(stmt!=null)
		            stmt.close();
		      }catch(SQLException se2){
		      }// nothing we can do
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try
		
		System.out.println("Goodbye!");
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		user_credentials u = new user_credentials();
		
		     System.out.println(u. username_useid_map.get("46"));
//		     System.out.println(u.username_password_map.get("pdhead"));
	}

}
