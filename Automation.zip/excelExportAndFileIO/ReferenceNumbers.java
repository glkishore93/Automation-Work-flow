package excelExportAndFileIO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Scanner;

import org.openqa.selenium.WebDriver;

public class ReferenceNumbers {
	static WebDriver driver;
	static final String JDBC_DRIVER = "com.sqlserver.jdbc.Driver";  
	static final String DB_URL = "jdbc:sqlserver://192.168.0.1\\sql_14";
	static final String USER = "kishore";
	static final String PASS = "Temp@123";
	static String ids;
	static String ref;
	public ReferenceNumbers() {
		ids=stepiduserid();
		// TODO Auto-generated constructor stub
	}
	public String getformid() {
		Connection conn = null;
		Statement stmt = null;

		 String formid="";
		 String ref_num="";
			try{

				  DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
				   //STEP 3: Open a connection
			      System.out.println("Connecting to database...");
			      conn = DriverManager.getConnection(DB_URL,USER,PASS);
			  

			      //STEP 4: Execute a query
			      System.out.println("Creating statement...");
			      stmt = conn.createStatement();
			      String sql1 = "select FORM_NF_ID from [Greatfour_Platform_HarmonyV4.0].[dbo].[FORMS] where FORM_CF_REFERENCE_NUMBER =";
			      Scanner sc = new Scanner(System.in);
			    
		//	     String array [];
			      System.out.println("Please Enter the reference Number......");
			     ref_num=sc.nextLine();
			     ref=ref_num;
			      sql1=sql1+ref_num;
			      System.out.println(sql1);
			      ResultSet rs=stmt.executeQuery(sql1);
       //     String flowid="";
			    while(rs.next()) {
			     
			      formid=rs.getString("FORM_NF_ID");
				    System.out.println("FORM ID :  "+formid);
			    }
			 //   System.out.println("FORM ID :  "+formid);
			      rs.close();				     
			      stmt.close();
			      conn.close();
			      System.out.println(formid);
			return formid;
			 
		   }catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		            stmt.close();
		      }catch(SQLException se2){
		      }// nothing we can do
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try
		   System.out.println("Goodbye!"+formid);
			return null;
		}
	public String stepiduserid() {
		Connection conn = null;
		Statement stmt = null;
		String formid = getformid();
	//	WriteExcel w = new WriteExcel();
	System.out.println("FORM ID :  "+formid);
			try{

				  DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
				   //STEP 3: Open a connection
			      System.out.println("Connecting to database...");
			      conn = DriverManager.getConnection(DB_URL,USER,PASS);
			  

			      //STEP 4: Execute a query [FORMS]
			      System.out.println("Creating statement...");
			      stmt = conn.createStatement();
			      String sql1 = "select UA_NF_STEP_ID,UA_NF_USR_ID from [Greatfour_Platform_HarmonyV4.0].[dbo].[USER_AUTHORIZATION] where UA_NF_FORM_ID =";
			      Scanner sc = new Scanner(System.in);
			  
			      sql1=sql1+formid;
			      System.out.println(sql1);
			      ResultSet rs=stmt.executeQuery(sql1);
			     //     String flowid="";
			      String stepid="";
			      String userid="";
			     
			      while(rs.next()) {
			     
			      stepid=stepid+","+rs.getString("UA_NF_STEP_ID");
			      userid=userid+","+rs.getString("UA_NF_USR_ID");
			      System.out.println(stepid+"hiiii"+userid);
			    }
			  
			      rs.close();				     
			      stmt.close();
			      conn.close();
			      System.out.println(formid);
			return stepid+",,"+userid;
			 
		   }catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		            stmt.close();
		      }catch(SQLException se2){
		      }// nothing we can do
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try
		   System.out.println("Goodbye!");
			return null;
	
	}
	public String [] getstepid_in_0_nd_userid_in_1() {
		System.out.println(ids);
		String ar []=ids.split(",,");
		
		
		return ar;
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ReferenceNumbers r = new ReferenceNumbers();
		

		;
		System.out.println(Arrays.toString(r.getstepid_in_0_nd_userid_in_1()));
		//System.out.println(Arrays.toString(r.getuserid()));
	     
	      
		   
	}

}
