package excelExportAndFileIO;

import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class InitiationForm {
	
	
	/**
	 * @throws Exception 
	 * 
	 */
	public static WebDriver driver;
	public static FileInputStream fis;
	public static String c;
	public static String c1;
	public static XSSFWorkbook workbook;
	public static String fiss[];																																																																																																																																																																																																																																																																					public static XSSFSheet sheet; 
	public static String filepath;																																																																																																																																																																																																																																																																					public static Row row1;
																																																																																																																																																																																																																																																																						public static Row row2;
																																																																																																																																																																																																																																																																						public static Row row3;
																																																																																																																																																																																																																																																																						
	public InitiationForm(WebDriver driver,String s) throws Exception{
		// TODO Auto-generated constructor stub
//		System.setProperty("webdriver.ie.driver", "C:\\\\Users\\G411\\Downloads\\IEDriverServer_Win32_3.8.0\\IEDriverServer.exe");		
	
		InitiationForm.driver=driver;
		System.out.println(driver);
		String f [] =s.split(",");
		System.out.println("hi  this is the filepath : "+f[3]);
		fis = new FileInputStream("C:\\\\Users\\\\G411\\\\Desktop\\\\Initiation\\\\sampleinitiate.xlsx");
		 workbook= new XSSFWorkbook(fis);	
		System.out.println("checking.............................11111111111111111111");
		 sheet= workbook.getSheetAt(0);
		row1 = sheet.getRow(2);
		row2 =sheet.getRow(3);
		row3 = sheet.getRow(170);
		c = row1.getCell(1).getStringCellValue();
		c1 = row2.getCell(1).getStringCellValue();
		
		Thread.sleep(4000);
		newintiate();
		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
		initiateNewFormdropdown();
		
		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
		initiateNewFormtextbox();
		initiateButton();
		Thread.sleep(2000);
		
	}
	public  void initiateNewFormtextbox() throws Exception{
		Databaseconnect d = new Databaseconnect();
		
		int rc = d.textbox_ids.size();
		System.out.println(rc);
		System.out.println("Before text box loop"+c);
		String[] j= c.split(",");
		String[] j1= c1.split(",");
		int icount=Integer.parseInt(j[0]);
		int jcount=Integer.parseInt(j1[0]);
		System.out.println(j1[0]);
		System.out.println();
		long total_time =0;
		for(int i=icount+4;i<icount+jcount+5;i++) {
			System.out.println("inside the loop");
			Row row = sheet.getRow(i);
		
			String id = row.getCell(0).getStringCellValue();
			long start_time = System.currentTimeMillis();
			
			try {
		
			WebElement w = driver.findElement(By.id(id));
			System.out.println("hihi hio 3");
			
			if(w.isEnabled()) {
			
				System.out.println("hihi hio");	
		//		w.getScreenshotAs();
				w.sendKeys(row.getCell(2).getStringCellValue());
			
			}
			
			}
	
			catch(Exception e) {
				long end_time = System.currentTimeMillis();
				System.out.println(id+"\t"+i+"\t"+"Total Time taken "+"\n");
				long time_taken = end_time-start_time; 
				total_time = total_time + time_taken;
				System.out.println(total_time+"\n");
				continue;
			}
			long end_time = System.currentTimeMillis();
			System.out.println(id+"\t"+i+"\t"+"Total Time taken "+"\n");
			long time_taken = end_time-start_time; 
			total_time =total_time + time_taken;
			System.out.println(total_time+"\n");
			
		}		
		
	}
	
	public   void initiateNewFormdropdown() throws Exception  {
			
		XSSFSheet sheet = workbook.getSheetAt(0);
		int rc = sheet.getPhysicalNumberOfRows();
		System.out.println(rc);
		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	
		driver.findElement(By.cssSelector("div.ms-options-wrap > button")).click();
		Thread.sleep(3000);
		//driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
		driver.findElement(By.cssSelector("li > label")).click();
		String[] j= c.split(",");
		long total_time=0;
		System.out.println("before the loop");
		for(int i=4;i<Integer.parseInt(j[0])+4;i++) {
			Row row = sheet.getRow(i);
			long start_time = System.currentTimeMillis();
			String id = row.getCell(0).getStringCellValue();
		
			System.out.println(id);
			try {
				WebElement w = driver.findElement(By.id(id));
			
					System.out.println("Element is enabled");
					Select listbox = new Select(w);
					
					//System.out.println("JSDYAZ");
					w.click();			
					listbox.selectByVisibleText(row.getCell(2).getStringCellValue());
					System.out.println("Element  is found and Selected : "+ "\n");
					
				
			}
			
			catch (Exception e) {
				System.out.println(e);
				long end_time = System.currentTimeMillis();
				System.out.println(id+"\t"+i+"\t"+"Total Time taken "+"\n");
				long time_taken= end_time-start_time;
				total_time =total_time+time_taken;
				System.out.println(total_time +"in catch block" +"\n");
				continue;
			}
			long end_time = System.currentTimeMillis();
			System.out.println(id+"\t"+i+"\t"+"Total Time taken "+"\n");
			total_time = end_time-start_time;
			System.out.println(total_time+" final"+ "\n");
		
	
			
		}		
	
		
	}
	
	public void initiateButton() throws InterruptedException {

		driver.findElement(By.id("btn7")).click();

		driver.findElement(By.cssSelector("div.alertcontent")).click();

		driver.findElement(By.id("btnFirst")).click();
		
		driver.findElement(By.cssSelector("div.alertcontent")).click();

		driver.findElement(By.id("btnFirst")).click();

	}
	
	public void newintiate()  {
		System.out.println("checking....................................");
			//	Thread.sleep(4000);
		driver.findElement(By.cssSelector("img.imgharmonyapps")).click();
		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
		driver.findElement(By.id("div'7'")).click();
		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
		driver.findElement(By.id("btnNewRequest")).click();
		
	}
	public static void main(String[] args) throws Exception {
		
	}	
}