package excelExportAndFileIO;
import java.sql.*;
import java.util.*;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Databaseconnect {
	static final String JDBC_DRIVER = "com.sqlserver.jdbc.Driver";  
	static final String DB_URL = "jdbc:sqlserver://192.168.0.1\\sql_14";
	static final String USER = "kishore";
	static final String PASS = "Temp@123";

	List<String> combo_ids ;
	List<String> textbox_ids;
	

	public Databaseconnect() {
		combo_ids = new ArrayList<String>();
		textbox_ids = new ArrayList<String>();
		
	}
	
	public void data() {
		Connection conn = null;
		   Statement stmt = null;
		   List<String> fieldnames =new ArrayList<String>();
		   try{
		      //STEP 2: Register JDBC driver C:\\Users\\G411\\Downloads\\excel\\sampleinitiate.xlsx
			   DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
			   //STEP 3: Open a connection
		      System.out.println("Connecting to database...");
		      conn = DriverManager.getConnection(DB_URL,USER,PASS);
		  

		      //STEP 4: Execute a query
		      System.out.println("Creating statement...");
		      stmt = conn.createStatement();
		      String sql;
		      String sql1;
		      sql = "select FLD_NF_ID,FLD_CF_NAME from [Greatfour_Platform_HarmonyV4.0].dbo.fields where FLD_TEMPLATEID = 7  and FLD_NF_STATUS =1 AND  FLD_NF_INITIATE_MANDATORY=1 and fld_cf_datatype=2  Order  By FLD_NF_DISPLAY_ORDER";
		    
		      ResultSet rs = stmt.executeQuery(sql);

		      //STEP 5: Extract data from result set

		     
		      String id ="";
		      String fieldname="";
		     
		      XSSFWorkbook  workbook = new XSSFWorkbook("C:\\\\Users\\\\G411\\\\Desktop\\\\Initiation\\\\sampleinitiate.xlsx");		
				XSSFSheet sheet = workbook.getSheetAt(0);
		     
		      WriteExcel w = new WriteExcel();
		      int i=combo_ids.size()+4;
		      System.out.println(i);
		     
		      while(rs.next() ){
		         //Retrieve by column name
		         id  = rs.getString("FLD_NF_ID");
		         fieldname=rs.getString("FLD_CF_NAME");
		         textbox_ids.add(id);
		         fieldnames.add(fieldname);
		      }
		      
		      int lstrow =textbox_ids.size()+3;
		      System.out.println(lstrow);
		     String c =""+ textbox_ids.size();
		      int j=0;
		      w.writenewExcelltext(3, "C:\\\\Users\\\\G411\\\\Desktop\\\\Initiation\\\\sampleinitiate.xlsx" , "  text boxes",c);
		      while(j<textbox_ids.size()) {
		         w.writenewExcelltext(i, "C:\\\\Users\\\\G411\\\\Desktop\\\\Initiation\\\\sampleinitiate.xlsx", textbox_ids.get(j),fieldnames.get(j));
		         i++;
		         j++;
		      }
		      
		      rs.close();
		     
		      stmt.close();
		      conn.close();
		   }catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		            stmt.close();
		      }catch(SQLException se2){
		      }// nothing we can do
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try
		   System.out.println("Goodbye!");
	}
	
	public void datacombo() {
		Connection conn = null;
		   Statement stmt = null;
	
		   List<String> field_names = new ArrayList<String>();
		   try{
		      //STEP 2: Register JDBC driver C:\\Users\\G411\\Downloads\\excel\\sampleinitiate.xlsx
			   DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
			   //STEP 3: Open a connection
		      System.out.println("Connecting to database...");
		      conn = DriverManager.getConnection(DB_URL,USER,PASS);
		  

		      //STEP 4: Execute a query
		      System.out.println("Creating statement...");
		      stmt = conn.createStatement();
		      String sql;
		      String sql1;
		     
		      sql1 = "select FLD_NF_ID,FLD_CF_NAME from [Greatfour_Platform_HarmonyV4.0].dbo.fields where FLD_TEMPLATEID = 7  and FLD_NF_STATUS=1 and FLD_NF_INITIATE_MANDATORY=1 AND fld_cf_datatype=4 or fld_cf_datatype=42   Order By FLD_NF_DISPLAY_ORDER";
		     
		      ResultSet rs1 =stmt.executeQuery(sql1);
		      //STEP 5: Extract data from result set
		      String id1 ="";
		      String fieldname1="";
		 	 
		      
		 	 WriteExcel w = new WriteExcel();
		      while(rs1.next()) {
		    	     id1  = rs1.getString("FLD_NF_ID");
		 	         fieldname1=rs1.getString("FLD_CF_NAME");
		 	         combo_ids.add(id1);
		 	         field_names.add(fieldname1);
		 	   
		      }
		      String c = ""+combo_ids.size();
		      w.writenewExcell(2, "C:\\\\Users\\\\G411\\\\Desktop\\\\Initiation\\\\sampleinitiate.xlsx", "combox count",c);
		      int i=4;
		      int j=0;
		      System.out.println(combo_ids);
		      while(j<combo_ids.size()) {
		    	  w.writenewExcell(i, "C:\\\\Users\\\\G411\\\\Desktop\\\\Initiation\\\\sampleinitiate.xlsx", combo_ids.get(j),field_names.get(j));
		    	  i++;
		    	  j++;
		      }
		System.out.println(combo_ids.size());
		      //STEP 6: Clean-up environment

		      
		      rs1.close();
		     
		   
		     
		      stmt.close();
		      conn.close();
		   }catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		            stmt.close();
		      }catch(SQLException se2){
		      }// nothing we can do
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try
		   System.out.println("Goodbye!");
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub	
	
		Databaseconnect d = new Databaseconnect();
		d.datacombo();
		d.data();
	//	d.datatextbox();
		
		
	}//end main
}//end FirstExample
