package excelExportAndFileIO;
import java.io.FileInputStream;
//import java.lang.reflect.Constructor;
import java.util.Arrays;
import java.lang.reflect.*;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import javax.swing.*;

import java.awt.Color;
import java.awt.event.*; 
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


public class Controller {
	public static final String[] searchPackages = {"java.lang","java.util" };
	private static XSSFWorkbook workbook;
	static WebDriver driver;
	static JFrame f;    
	public Controller() {
		System.setProperty("webdriver.ie.driver", "C:\\Users\\G411\\Downloads\\IEDriverServer_Win32_3.8.0\\IEDriverServer.exe");		
		driver = new InternetExplorerDriver();	
		
	}
	  public Class<?> findClassByName(String name) {
		    for(int i=0; i<searchPackages.length; i++){
		      try{
		        return Class.forName(searchPackages[i] + "." + name);
		      } catch (ClassNotFoundException e){
		        System.out.println(e);
		    	  //not in this package, try another
		      } catch (Exception ee){
		    	  System.out.println(ee);
		    	  //deal with other problems...
		      }
		    }
		    //nothing found: return null or throw ClassNotFoundException
		    return null;
		  }
	
	public static void main(String[] args) throws Exception {
	
		Controller c = new Controller();				
		FileInputStream fis = new FileInputStream("C:\\Users\\G411\\Desktop\\control\\Controller_class.xlsx");
		workbook = new XSSFWorkbook(fis);		
		XSSFSheet sheet = workbook.getSheetAt(0);
		int rc = sheet.getLastRowNum();
		System.out.println(rc);

	

	    Map<String,String> TestcaseMap  = new HashMap<String, String>();
	    Map<String,String> ClassMap  = new HashMap<String, String>();
	    Map<String,String> valueMap  = new HashMap<String, String>();
	    
		String[] Classes = new String [rc+1];
		String[] Values = new String [rc+1];
		String Test_Case []=new String[rc+1];
		String classkey=null;
		String classkeyArray[];
		for(int j=0;j<=rc;j++) {
			Row row1 = sheet.getRow(j);
			String Test_case=row1.getCell(0).getStringCellValue();
			String className = row1.getCell(1).getStringCellValue();
			String values = row1.getCell(2).getStringCellValue();
			Test_Case[j]=Test_case; 
			Classes[j]=className;
			String valuesArray[]=values.split(",,,");
		//	 System.out.println(Arrays.toString(Test_Case));
			 TestcaseMap.put(Test_Case[j],Classes[j]);
		
			classkey= TestcaseMap.get(Test_Case[j]);
			classkeyArray=classkey.split(",");
		//	System.out.println(Arrays.toString(valuesArray));
			for(int i=0;i<classkeyArray.length;i++) {
				ClassMap.put(classkeyArray[i],valuesArray[i]);
				 Iterator<?> iter = ClassMap.entrySet().iterator();
//				 while (iter.hasNext()) {
//				     Map.Entry mEntry = (Map.Entry) iter.next();
//			   System.out.println(mEntry.getKey() + " : " + mEntry.getValue());
//				 }

			}
		 }
	    	JFrame f=new JFrame("Harmony_v4.0");     
	    	 f.setBackground(Color.BLUE);
		    final JComboBox<Object> cb=new JComboBox<Object>(Test_Case);  
		    final JButton b =new JButton("Mandatory");
		    
		    cb.setBounds(50, 80,100,20);    
		   
		   
		    f.setLayout(null);    
		    f.setSize(500,500);    
		   
		    f.setVisible(true);
		   
		    JLabel label=new JLabel();
		   
		    f.add(b);
		    f.add(label); ;
		    
		    f.add(cb); 
		    
		    b.setBounds(300, 80,100,20);
		    b.addActionListener(new ActionListener() {
		    	public void actionPerformed(ActionEvent e2) {
		    		  Class<?> cls;
					try {
						cls = Class.forName("excelExportAndFileIO.Databaseconnect");
						 Method meth;
						
							meth = cls.getMethod("main", String[].class);
						  String[] params = null; // init params accordingly
		    			 
								meth.invoke(null, (Object) params);
							} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException | SecurityException | ClassNotFoundException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} // static method doesn't have an instance
					
		    			   
		    	
		    	}
		    });
		   
		     cb.addActionListener(new ActionListener() {
		    	 public void actionPerformed(ActionEvent e1) {
		    		 String data1=""+ cb.getItemAt(cb.getSelectedIndex()); 
		    		 String Data1[]=TestcaseMap.get(data1).split(",");
		    		System.out.println(Arrays.toString(Data1));
		    		 String data2 ="Classes Executed :"+"  " ;
		    		for(int i=0;i<Data1.length;i++) {
		    				 data2 =data2+(i+1)+"."+" "+Data1[i]+"  ";
		    		}
		    		  System.out.println("qqqqqqqqqqqqqq"+data2+"\n");
		    		 label.setText(data2);
		  		    label.setBounds(50,50, 700,400);
		  		//    label.setVisible(true);
		  		 
		    	 }
		     });
		    cb.addActionListener(new ActionListener() {  
	        public  void actionPerformed(ActionEvent e) {       
				
	        	String data = ""+ cb.getItemAt(cb.getSelectedIndex()); 
				
				
				System.out.println(data+"\n");
				String val= TestcaseMap.get(data);
				System.out.println(val);
				String classnames []=val.split(",")  ;
				
				//System.out.println(Arrays.toString(classnames));
				
				
				for(int k=0;k<classnames.length;k++) {
					//System.out.println(classnames.length);
					String user=ClassMap.get(classnames[k]);
					String credentials[] = user.split(",");
					
					
					//System.out.println(Arrays.toString(credentials));
					for(int l=0;l<credentials.length;l++) {
						String temp []=credentials[l].split("::");
					//	System.out.print("\n"+temp[0]+" , "+temp[1]+"\n");
						valueMap.put(temp[0], temp[1]);
					
					}
				}
				String s =valueMap.get( "username")+","+valueMap.get( "password")+","+valueMap.get( "url")+","+valueMap.get( "Initiatefilepath")+","+valueMap.get( "Dashboardfilepath")+","+valueMap.get("RefNum")+","+valueMap.get("NA")+","+valueMap.get("platform");
//					 Iterator iter = valueMap.entrySet().iterator();
//					 while (iter.hasNext()) {
//					 Map.Entry mEntry = (Map.Entry) iter.next();
//				   	System.out.println(mEntry.getKey() + " : " + mEntry.getValue());
//					 }
				String currentClassNames[] = TestcaseMap.get(data).split(",");	
				System.out.println(Arrays.toString(currentClassNames));
				for(int h=0;h<currentClassNames.length;h++) {
				
					try {	 
						System.out.println("This iteration is:  "+h);					
						System.out.println("Before clsname  : ");
						String c="excelExportAndFileIO."+currentClassNames[h];
						Class<?> clsname = Class.forName(c);
						System.out.println("After clsname  : ");
						System.out.println(clsname);
					
					    System.out.println(s);	
					    String vall[]=s.split(",");
						if(clsname.getCanonicalName().equals("excelExportAndFileIO.Logout")) {
							Thread.sleep(3000);
							System.out.println("1111");
							Constructor<?> ctor1 = clsname.getConstructor(WebDriver.class);
							Object object1 = ctor1.newInstance(new Object[] {driver});
				
					}					
					else {
						Thread.sleep(2000);
						System.out.println("hello");
						
						Constructor<?> ctor2 = clsname.getConstructor(WebDriver.class,String.class);
						//System.out.println(valueMap.get("Dashboardfilepath"));
						Object object1 = ctor2.newInstance(new Object[] {driver,s});
						System.out.println("hello111");
						}
					Thread.sleep(2000);
					}
			catch(Exception e1) {
				System.out.println(e1);
				continue;
			}
			
				}
					}
	        
	}); 
		    
	}
}
				
				//				String clsnm[]=cln[0].split(",");
//				for(int k=0;k<clsnm.length;k++) {
//					System.out.println("clasnm"+"\t"+clsnm[k]);
//					try {
//					
//						Class<?> clsname = Class.forName(clsnm[k]);
//						String []value =cln[1].split(",,,");
//						String []number_of_values=value[0].split(",");
//						for(int l=0;l<number_of_values.length;l++) {
//					
//							String []named_Value_pairs=number_of_values[l].split("::");
//							String Key=named_Value_pairs[0];
//							String key_value=named_Value_pairs[1];
//							mMap1.put(Key, key_value);
//							System.out.println(Arrays.toString(named_Value_pairs));
//							 Iterator iter = mMap1.entrySet().iterator();
//							while(iter.hasNext()) {
//							String val=mMap1.get();
//							
//							if(val.equals("NA")) {
//								Constructor<?> ctor1 = clsname.getConstructor(WebDriver.class);
//								Object object1 = ctor1.newInstance(new Object[] {driver});
//											
//							}
//							else {
//								System.out.println("hello");
//								Constructor<?> ctor1 = clsname.getConstructor(WebDriver.class,String.class);
//								System.out.println(driver);
//								Object object1 = ctor1.newInstance(new Object[] {driver,val});
//								System.out.println("hello111");
//								}
//							}
//						}	
//							}
//							catch(Exception e1) {
//								System.out.println(e1);
//								
//							}
//						}	
//					
//				
				


		    
	
		  //  System.out.println(i);
		
	//	driver.quit();

 	