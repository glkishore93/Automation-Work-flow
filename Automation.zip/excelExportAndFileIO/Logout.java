package excelExportAndFileIO;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class Logout{
	static WebDriver driver;
	public Logout(WebDriver driver) throws InterruptedException {
		Logout.driver=driver;
		logout();
	}
	
	public void logout() throws InterruptedException {
		Thread.sleep(4000);
		WebElement we = driver.findElement(By.cssSelector("label.lblmpdrpdwnshrtname.whitecolorfont"));
		we.click();		
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("button.hrmnybtn")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("div.alertbuttons > #btnFirst")).click();

}
	public static void main(String[] args) {
				
	}
}