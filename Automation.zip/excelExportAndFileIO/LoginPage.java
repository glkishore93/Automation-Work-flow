package excelExportAndFileIO;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.gargoylesoftware.htmlunit.javascript.host.Map;
public class LoginPage {
	public static WebDriver driver;
	
	public LoginPage(WebDriver driver,String s) throws InterruptedException  {
		// TODO Auto-generated constructor stub
		/******to set propert to use internet explorer driver which arte located in the following path ********/
		LoginPage.driver=driver;
	
		//String value [] =s.split(",");
		String url[]=s.split(",");
		geturl(url[2]);
		platform(url[7]);
		//String username=""+s.get("username");
	//	String password=""+s.get("password");
		Thread.sleep(1500);
		login(url[0],url[1]);
		
	}
	public LoginPage() {
		
	}
	
	public void geturl(String s) {
		String url =s;
		driver.get(url);
	}

	public void login(String s,String s1) throws InterruptedException {
		driver.manage().window().maximize();
		
		driver.findElement(By.id("txtLoginName")).sendKeys(s);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.id("txtPassword")).sendKeys(s1);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.id("btnLogin")).click();		
	}
	public void platform(String s) {
		WebElement w = driver.findElement(By.id("dbNames"));
		w.click();
		Select listbox = new Select(w);
		listbox.selectByVisibleText(s);
	}
	public String handlePopup() throws InterruptedException {
		
		String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
		
		String subWindowHandler = null;
		
		Set<String> handles = driver.getWindowHandles();
		
		Iterator<String> iterator = handles.iterator();
		
		String message="";	
	
		while (iterator.hasNext()){
			    subWindowHandler = iterator.next();			   
		
			    driver.switchTo().window(subWindowHandler); // switch to popup window
			    
			    driver.findElement(By.cssSelector("div.alertcontent")).click();
			    
			    message = driver.findElement(By.cssSelector("div.alertcontent")).getText();
			    Thread.sleep(3000);
			    }
			    
	    driver.findElement(By.id("btnOK")).click();
	    Thread.sleep(3000);
	    driver.switchTo().window(parentWindowHandler);  
	    return message;	    
	}
	
	
	
	public static void main(String[] args) throws Exception {
		
	}

}
