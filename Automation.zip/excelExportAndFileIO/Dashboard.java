package excelExportAndFileIO;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;

public class Dashboard {
	static WebDriver driver;
	static final String JDBC_DRIVER = "com.sqlserver.jdbc.Driver";  
	static final String DB_URL = "jdbc:sqlserver://DESKTOP-5HDDC1U";
	static final String USER = "kishore";
	static final String PASS = "pp@123";
	public static FileInputStream fis;
	public static XSSFWorkbook workbook;
	static XSSFSheet sheet;
	static XSSFRow row;
	static  String fieldids [];
	public Dashboard(WebDriver driver,String s) throws InterruptedException, IOException {
		Dashboard.driver=driver;
		String f []= s.split(",");
		System.out.println(f[4]+"dddddddddddddddddddddddddddd");
			
		 System.out.println("checkkkkkkkkkkkkkkkk");
		Thread.sleep(3000);
		
	//	authorise();
		Thread.sleep(3000);
		initiateFromDashborad();
		Thread.sleep(3000);
		
		
		Thread.sleep(3000);
		createExcelsheet();
		Thread.sleep(3000);
		fillRemainingfields();
	}
	
	public void authorise() {
		System.out.println("authoriseeeeeeeeeeee");
		driver.findElement(By.cssSelector("#dvAllCheckListPercentage > span")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.id("AuthurAll")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.id("btnFirst")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.id("btnFirst")).click();
	}
	public void initiateFromDashborad() throws InterruptedException { 
		System.out.println("/////////////////DashBoard//////////////////////");
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[contains(text(),'2018\\582-1')]")).click();
		//driver.findElement(By.name("2018\\582-1")).click();
		//driver.findElement(By.cssSelector("a.gridActionButton")).click();
		
		System.out.println("/////////////////DashBoard complete//////////////////////");
	}
	public String []  databaseIds() {
		Connection conn = null;
		Statement stmt = null;
		String fields="";
		 try{
		      //STEP 2: Register JDBC driver C:\\Users\\G411\\Downloads\\excel\\sampleinitiate.xlsx
			   DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
			   //STEP 3: Open a connection
		      System.out.println("Connecting to database...");
		      conn = DriverManager.getConnection(DB_URL,USER,PASS);
		  

		      //STEP 4: Execute a query
		      System.out.println("Creating statement...");
		      stmt = conn.createStatement();
		      String sql;
		      sql="select WFDEF_CF_ENABLED_FIELDS from Troikaa_Dev_Harmony.dbo.WORKFLOW_DEFINITION where WFDEF_WFM_NF_ID=2009 and WFDEF_NF_SEQUENCE=1";
		      ResultSet rs  = stmt.executeQuery(sql);
		      while(rs.next()) {
		     
		      fields = rs.getString("WFDEF_CF_ENABLED_FIELDS");
		     }
		      rs.close();
			     
		      stmt.close();
		      conn.close();
		
		 
	   }catch(SQLException se){
	      //Handle errors for JDBC
	      se.printStackTrace();
	   }catch(Exception e){
	      //Handle errors for Class.forName
	      e.printStackTrace();
	   }finally{
	      //finally block used to close resources
	      try{
	         if(stmt!=null)
	            stmt.close();
	      }catch(SQLException se2){
	      }// nothing we can do
	      try{
	         if(conn!=null)
	            conn.close();
	      }catch(SQLException se){
	         se.printStackTrace();
	      }//end finally try
	   }//end try
	   System.out.println("Goodbye!");
	   

	   return fields.split(",");
	}
	
	public void createExcelsheet() {
		String fields [] = databaseIds();
		Connection conn = null;
		Statement stmt = null;
		WriteExcel w = new WriteExcel();
		for(int i =0;i<fields.length;i++) {
			 try{

				   DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
				   //STEP 3: Open a connection
			      System.out.println("Connecting to database...");
			      conn = DriverManager.getConnection(DB_URL,USER,PASS);
			  

			      //STEP 4: Execute a query
			      System.out.println("Creating statement...");
			      stmt = conn.createStatement();
			      String tempsql="select FLD_CF_DATATYPE,FLD_CF_NAME from  Troikaa_Dev_Harmony.dbo.fields where FLD_TEMPLATEID=7 and FLD_NF_ID=";
			      String sql;
			      sql=tempsql+fields[i];
			      
			      ResultSet rs  = stmt.executeQuery(sql);
			      while(rs.next()) {
			     
			      String datatype = rs.getString("FLD_CF_DATATYPE");
			      String name =rs.getString("FLD_CF_NAME");
			      String fispath="C:\\Users\\G411\\Desktop\\control\\Dashboard.xlsx";
			      w.writeExcell(i+1, fields[i],fispath, name, datatype);
			      
			     }
			      rs.close();
				     
			      stmt.close();
			      conn.close();
			
			 
		   }catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		            stmt.close();
		      }catch(SQLException se2){
		      }// nothing we can do
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try
		   System.out.println("Goodbye!");
			
		}
	}
	public void fillRemainingfields() throws IOException, InterruptedException {
		fis = new FileInputStream("C:\\Users\\G411\\Desktop\\control\\Dashboard.xlsx");
		 workbook= new XSSFWorkbook(fis); 
		XSSFSheet sheet= workbook.getSheetAt(0);
	//	System.out.println(Arrays.toString(fieldids));
		 int rc = sheet.getLastRowNum();
		for(int i=1;i<rc;i++) {
			System.out.println("inside the loop");
			 row =sheet.getRow(i);
			 String id = row.getCell(0).getStringCellValue();
			 String datatype =row.getCell(1).getStringCellValue();
			 System.out.println(datatype);
			 
			 if(datatype.equals("4")) {
				 try {
					 	System.out.println("In try");
						WebElement w = driver.findElement(By.id(id));
							if(w.isEnabled()) {	
							System.out.println("Element is enabled");
							Select listbox = new Select(w);
							
							//System.out.println("JSDYAZ");
							w.click();			
							listbox.selectByVisibleText(row.getCell(3).getStringCellValue());
							System.out.println("Element  is found and Selected : "+ "\n");
							}
						
					}
				 catch(Exception e) {
					 System.out.println(e);
					 continue;
				}
				  
				 
			 }
		
		}
		Thread.sleep(2000);
		 driver.findElement(By.id("btn6")).click();
		 driver.findElement(By.id("btnFirst")).click();
	}
	public static void main(String args[]) throws InterruptedException, IOException {
		
		
	}
}
