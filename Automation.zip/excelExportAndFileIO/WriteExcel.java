package excelExportAndFileIO;
/**
 * @author Leela Kishore
 *
 */
import java.io.FileInputStream;
import java.io.FileOutputStream;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class WriteExcel {
	
		 XSSFWorkbook workbook;
		 WriteExcel(){
			 
		 }
		@SuppressWarnings({ })
	public void writenewExcelltext(int count,String fispath,String s,String s1) throws Exception {
		FileInputStream fis = new FileInputStream(fispath);
		workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheetAt(0);
	
			int a=count;
			Row row =sheet.getRow(a);
		    Cell cell = null;
		    Cell cell1 =null;
		    
	        XSSFFont font = workbook.createFont();
	        XSSFCellStyle style = workbook.createCellStyle();
	        row = sheet.getRow(a);
	       ////////////////////////
	        font.setFontName("Calibri");
	        font.setFontHeight(12.0);
	     
	        style.setFont(font);
	    
	  
	        row = sheet.createRow(a);     
	        cell = row.createCell(0);
	        cell1 = row.createCell(1);
	        
//	    	cell.setCellStyle(style);
	    	cell.setCellValue(s);
	    	cell1.setCellValue(s1+",Text box");
	
        FileOutputStream  fos = new FileOutputStream(fispath);
        workbook.write(fos);
        fos.close();
	
		}
		public void writenewExcell(int count,String fispath,String s,String s1) throws Exception {
			FileInputStream fis = new FileInputStream(fispath);
			workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheetAt(0);
		
				int a=count;
				Row row =sheet.getRow(a);
			    Cell cell = null;
			    Cell cell1 =null;
			    
		        XSSFFont font = workbook.createFont();
		        XSSFCellStyle style = workbook.createCellStyle();
		        row = sheet.getRow(a);
		       ////////////////////////
		        font.setFontName("Calibri");
		        font.setFontHeight(12.0);
		     
		        style.setFont(font);
		    
		  
		        row = sheet.createRow(a);     
		        cell = row.createCell(0);
		        cell1 = row.createCell(1);
		        
//		    	cell.setCellStyle(style);
		    	cell.setCellValue(s);
		    	cell1.setCellValue(s1+",combo box");
		
	        FileOutputStream  fos = new FileOutputStream(fispath);
	        workbook.write(fos);
	        fos.close();
		
			}
		public void writeExcell(int count,String id,String fispath,String s,String s1) throws Exception {
			FileInputStream fis = new FileInputStream(fispath);
			workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheetAt(0);
		
				int a=count;
				Row row =sheet.getRow(a);
			    Cell cell = null;
			    Cell cell1 =null;
			    Cell cell2=null;
		        XSSFFont font = workbook.createFont();
		        XSSFCellStyle style = workbook.createCellStyle();
		        row = sheet.getRow(a);
		       ////////////////////////
		        font.setFontName("Calibri");
		        font.setFontHeight(12.0);
		     
		        style.setFont(font);
		    
		  
		        row = sheet.createRow(a);     
		        cell = row.createCell(2);
		        cell1 = row.createCell(1);
		        cell2=row.createCell(0);
//		    	cell.setCellStyle(style);
		    	cell.setCellValue(s);
		    	cell1.setCellValue(s1);
		    	cell2.setCellValue(id);
		
	        FileOutputStream  fos = new FileOutputStream(fispath);
	        workbook.write(fos);
	        fos.close();
		
			}
//		public void writeExcell(int a,int rc,String fispath,String s) throws Exception {
//			FileInputStream fis = new FileInputStream(fispath);
//			workbook = new XSSFWorkbook(fis);
//			XSSFSheet sheet = workbook.getSheetAt(0);
//			for(int i=a;i<rc;i++) {
//			  Row row =sheet.getRow(i);
//			  Row row2 = null;
//		        Cell cell = null;
//		        XSSFFont font = workbook.createFont();
//		        XSSFCellStyle style = workbook.createCellStyle();
//		        System.out.print("IHLSDFASDHF");
//		        row2 = sheet.getRow(i);
//		        if(row2 == null)
//		            row2 = sheet.createRow(i);
//		 
//		        cell = row2.getCell(i);
//		        if(cell == null)
//		            cell = row2.createCell(i);
//		 
//		        font.setFontName("Calibri");
//		        font.setFontHeight(12.0);
//		        font.setBold(true);
//		        font.setColor(HSSFColor.RED.index);
//		 
//		        style.setFont(font);
//		        style.setFillForegroundColor(HSSFColor.YELLOW.index);
//		        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
//		        System.out.println(row.getCell(7).getStringCellValue()+"\t"+s);
//				 if(s.equals(row.getCell(7).getStringCellValue())) {
//					 
//				        cell.setCellStyle(style);
//				        cell.setCellValue("PASS");
//				 }
//				 else {
//					 cell.setCellStyle(style);
//			        cell.setCellValue("FAIL");
//				 }
//		      FileOutputStream  fos = new FileOutputStream(fispath);
//		        workbook.write(fos);
//		        fos.close();
//			}
//				}
//		public void writeExcellnopopup(int a,int rc,String fispath,String s) throws Exception {
//			FileInputStream fis = new FileInputStream(fispath);
//			workbook = new XSSFWorkbook(fis);
//			XSSFSheet sheet = workbook.getSheetAt(0);
//			for(int i=a;i<rc;i++) {
//			  Row row =sheet.getRow(i);
//			  Row row2 = null;
//		        Cell cell = null;
//		        XSSFFont font = workbook.createFont();
//		        XSSFCellStyle style = workbook.createCellStyle();
//		        
//		        row2 = sheet.getRow(i);
//		        if(row2 == null)
//		            row2 = sheet.createRow(1);
//		 
//		        cell = row2.getCell(8);
//		        if(cell == null)
//		            cell = row2.createCell(8);
//		 
//		        font.setFontName("Calibri");
//		        font.setFontHeight(12.0);
//		        font.setBold(true);
//		        font.setColor(HSSFColor.RED.index);
//		 
//		        style.setFont(font);
//		        style.setFillForegroundColor(HSSFColor.YELLOW.index);
//		        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
//
//				
//					 
//				        cell.setCellStyle(style);
//				        cell.setCellValue(s);
//				
//					 
//		      FileOutputStream  fos = new FileOutputStream(fispath);
//		        workbook.write(fos);
//		        fos.close();
//			}
//				}
		
		

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
